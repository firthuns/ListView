package com.cieep.ejemplo05_listview;

import android.content.Intent;
import android.os.Bundle;

import com.cieep.ejemplo05_listview.adapters.NotasAdapter;
import com.cieep.ejemplo05_listview.modelos.Nota;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private final int EDIT_NOTA = 2;
    private final int CREAR_NOTA = 1;
    // 1. Conjuntos de Datos
    private ArrayList<Nota> listaNotas;
    // 2. Plantilla de los elementos
    private int plantillaFilas;
    // 3. Adapter para Listview
    private ListView listView;
    private NotasAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = inicializaDatos();



        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CrearNotaActivity.class);
                startActivityForResult(intent, CREAR_NOTA);
            }
        });
    }

    private FloatingActionButton inicializaDatos() {
        listaNotas = new ArrayList<>();
        plantillaFilas = R.layout.fila_nota;
        listView = findViewById(R.id.contenedorMain);
        adapter = new NotasAdapter(this, plantillaFilas, listaNotas);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Nota nota = listaNotas.get(i);
                nota = (Nota) adapterView.getItemAtPosition(i);
                Intent intent = new Intent(MainActivity.this, EditNotaActivity.class);
                Bundle bundle = new Bundle();
                bundle.putParcelable("NOTA", nota);
                bundle.putInt("POS", i);
                intent.putExtras(bundle);
                startActivityForResult(intent, EDIT_NOTA);
            }
        });

        return findViewById(R.id.fab);
    }

    private void inicializaNotas() {
        for (int i = 0; i < 10; i++) {
            Nota nota = new Nota("Titulo "+i, "Contenido", new Date());
            listaNotas.add(nota);
        }
        adapter.notifyDataSetChanged();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CREAR_NOTA && resultCode == RESULT_OK){
            if (data != null){
                if (data.getExtras() != null){
                    Nota nota = data.getExtras().getParcelable("NOTA");
                    if (nota != null){
                        listaNotas.add(nota);
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        }
        if (requestCode == EDIT_NOTA && resultCode == RESULT_OK) {
            if (data != null){
                if (data.getExtras() != null){
                    Nota nota = data.getExtras().getParcelable("NOTA");
                    int posicion = data.getExtras().getInt("POS");
                    if (nota != null){
                        listaNotas.set(posicion, nota);
                        adapter.notifyDataSetChanged();
                    }
                }
            }
        }
    }
}